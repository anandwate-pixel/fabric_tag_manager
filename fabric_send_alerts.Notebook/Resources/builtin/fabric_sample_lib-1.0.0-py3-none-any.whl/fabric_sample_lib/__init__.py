__version__ = "1.0.0"


def hello():
    return "hello from fabric_sample_lib 1.0.0"
